package com.firstApp.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;

/*
 * First three methods are life cycle methods
 */

public class LoginServlet implements Servlet {
	
	/**
	 * Init method is called only when first request is received
	 * 
	 */

	public void init(ServletConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("init method...........");
		

	}

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Service method..........");
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.write("This is login page");

	}
	
	/**
	 * Destroy method is called while shutting down the application
	 */

	public void destroy() {
		// TODO Auto-generated method stub
       System.out.println("Destroy method..................");
	}

	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

}
