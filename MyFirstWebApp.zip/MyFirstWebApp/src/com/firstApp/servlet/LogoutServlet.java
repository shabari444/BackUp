package com.firstApp.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;

public class LogoutServlet extends GenericServlet {
	
	@Override
	public void init() {
		System.out.println("Init method of LogoutServlet");
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("Service method of LogOutServlet");
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		pw.append("Logged out successfully");
		
	}

	@Override
	public void destroy() {
		System.out.println("Destroy method LoginServlet");
	}
}
