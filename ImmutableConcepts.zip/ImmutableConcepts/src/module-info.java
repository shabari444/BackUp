module ImmutableConcepts {
}