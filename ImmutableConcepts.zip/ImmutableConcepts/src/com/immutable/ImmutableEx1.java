package com.immutable;

public class ImmutableEx1 {
	
	public static void main(String[] args) {
		try {
			
		}catch(ArithmeticException ex) {
				
			}
		
		catch(NullPointerException ex) {
			
		} /*
			 * catch(Exception e) {
			 * 
			 * }
			 */
		Car c = new Jaguar();
		//c.p
		int j;
		float f;
		String s;
		//System.out.println(s);
		int i = 9 ;
		Integer n = new Integer(7);
		modify(i);
		System.out.println(i);
		int hp = 10;
		Car car1 = new Car();
		Car car2 = new Car();
		Car car3 = new Car();
		car1.setHp(hp);
		hp++;
		car2.setHp(hp);
		hp++;
		car3.setHp(hp);
		System.out.println(car1 instanceof Object);
		System.out.println(car1.getHp());
		System.out.println(car2.getHp());
		System.out.println(car3.getHp());
	}
	public static void modify(int i) {
		i = i+1;
	}

}