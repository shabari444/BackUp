package com.immutable;

import java.lang.annotation.Annotation;

import com.userDefinedAnnotation.Fuel;




@Fuel
public class Car {
	private int hp;
	private String name;

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static void main(String[] args) {
		Car car = new Car();
		Class c = car.getClass();
		Annotation ann = c.getAnnotation(Fuel.class);
		Fuel f = (Fuel) ann;
		System.out.println(f);
	}
}
