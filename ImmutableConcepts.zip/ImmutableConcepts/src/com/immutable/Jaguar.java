package com.immutable;

public class Jaguar extends Car {

	public void privateMethod() {
		System.out.println("Jagurs own method");
	}
}
