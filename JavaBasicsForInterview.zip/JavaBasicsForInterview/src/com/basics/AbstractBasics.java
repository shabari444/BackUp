package com.basics;

//A class can be abstract without any abstract methods;
public  abstract class  AbstractBasics {
	
	
public static void saySomething() {
	System.out.println("hi");
}

public static void main(String []args) {
	
	saySomething();
	
	//AbstractBasics ab = new AbstractBasics(); not possible
	
	//Class cl =// AbstractBasics.getClass();
}
}
