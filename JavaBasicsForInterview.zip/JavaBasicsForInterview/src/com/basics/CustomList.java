package com.basics;

import java.util.ArrayList;
import java.util.List;

public class CustomList {

	private int default_size;

	private Object[] objectArray;
	private int index;
	
	public static void main(String[] args) {
		List l = new ArrayList();
		System.out.println();
		CustomList col = new CustomList();
		col.add(1);
		col.add("E");
		col.add(2.0);
		col.add(null);
		col.add(1);
		col.add("E");
       for(int i = 0; i<col.size();i++) {
    	   System.out.println("element at "+ i+ "="+col.get(i));
       }
	}

	public CustomList() {
		this.default_size = 5;
		this.index = 0;
		this.objectArray = new Object[this.default_size];
	}

	public CustomList(Object[] objectArr) {
		this.objectArray = objectArr;
		default_size = objectArr.length;
	}

	public boolean add(Object ob) {
		if (index == default_size) {
			incermentSize();
		}

		objectArray[index++] = ob;

		return true;

	}

	public void incermentSize() {
		// objectArray.length = index++;
		int newSize = objectArray.length * 2;
		// default_size = newSize;
		Object newArray[] = new Object[newSize];
		int i = 0;
		for (Object o : objectArray) {
			newArray[i] = o;
			i++;
		}
		objectArray = newArray;

	}

	public Object get(int index) {
		if (index < objectArray.length) {
			return objectArray[index];
		} else {
			return null;
		}

	}
	
	public int size() {
		return index+1;
	}
	
	public boolean contains(Object o) {
		
		boolean isFound = false;
		
		for(int i = 0; i<=index;i++) {
			//if()
		}
		return isFound;
	}
	
}

class ExecuteCustomCollection {
	
}
