package com.basics;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

class Student {
	String name;
}
public class ArrayBasics {

	public static void main(String[] args) {
		int[] arr;
		// arr[0] = 1; //not valid since memory is nota llocated
		// Array array = new Array[5];cant initialize the Array since it has private
		// constructor
		arr = new int[5];
		int x = 10;
		Student s= new Student();
		s.name="Intialized";
		System.out.println(s.name);
		defTest(x, s);
		System.out.println(s.name);
	
		
		int[] randomArray = new int[20];
		
		Random r = new Random();
		
		for(int i = 0; i<randomArray.length;i++) {
			randomArray[i] = r.nextInt(100);
		}
		
		for(int i : randomArray) {
			System.out.println(i);
		}
		System.out.println("printing using streams");
		//Arrays.asList(randomArray).stream().filter((i)->i>50).
	   System.out.println( Arrays.asList(randomArray).stream());
	   
	   List<int[]> arrList = Arrays.asList(randomArray);
	   //filter((i)->i>10;)).
       // forEach(System.out::print);
		
		System.out.println(arr);// address of arr;
		System.out.println(arr.hashCode());
		// arr[6]=9;
		System.out.println(arr[4]);// print 0 i.e by deafault intializes with zero;
		arr = null;

		System.gc();

		/// System.out.println(arr[6]);//array index outof bound exception
	}
	
	public static void defTest(int x, Object o) {
		x = 15;
		Student s = new Student();
		s.name="changed";
	}
	
	interface RandomArray{
		public void printRandomArray(int arr[]);
	}
	
	public void executeRandomArrayPrinting(int arr[],RandomArray rArr) {
		
	    // for(int i: )
		
	}
}
