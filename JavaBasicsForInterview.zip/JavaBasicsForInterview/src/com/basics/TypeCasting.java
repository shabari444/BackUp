package com.basics;

public class TypeCasting {

	public static void main(String[] args) {
		Animal animalObj = new Cow();// narrowing
		animalObj.sound();
		// animalObj.extraThings();// not possible since its narrowed
		// Cow cowObj = new Animal();// not possible
		/*
		 * //Cow cowObj = (Cow) new Animal(); cowObj.sound(); // type cast exception
		 * since parent can't be casted to Child
		 * 
		 * cowObj.hashCode();
		 */
	}

}

class Animal {
	private String name;
	private int id;

	public void sound() {
		System.out.println("Animal Sound");
	}

	public void walk() {
		System.out.println("Animal can walk");
	}

}

class Cow extends Animal {

	public void sound() {
		super.sound();
		System.out.println("Cow  says ambaaaaaaaaaaa");
		super.sound();
	}

	public void extraThings() {
		System.out.println("Animals Extra things");
	}
}