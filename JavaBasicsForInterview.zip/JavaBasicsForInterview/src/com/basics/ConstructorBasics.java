package com.basics;

public class ConstructorBasics {

	private int a;
	private String name;

	public ConstructorBasics() {
		System.out.println("Parent default constructor");
	}

	public ConstructorBasics(int a, String name) {
		this.a = a;
		this.name = name;
		System.out.println(a);
		System.out.println(name);
	}

	public void test() {
		System.out.println(a);
		System.out.println(name);
	}

	protected void test1() {
		System.out.println("parent protected method");
	}

	private void privateParentMethod() {
		System.out.println("private parent method");
	}

	private static void staticprivateParentMethod() {
		System.out.println("private static parent method");
	}

	public static void staticParentMethod() {
		System.out.println("static parent method");
	}

	public static void main(String[] args) {

		ConstructorBasics b = new ConstructorBasics();
		int local = b.a;//b object is decalred with in the class so its accessible
		b.privateParentMethod();

		Derived d = new Derived(1, "Sha");// will give compile error if we define parameter
		// constructor without defeinf // default Constri=uctor
		d.test();
		Derived.staticParentMethod();// valid
		d.staticParentMethod();// valid
		// d.privateParentMethod();//invalid since private
		ConstructorBasics.staticprivateParentMethod();//invalid since private not
		// accesseble outside of he class;
		b=d;//narrowing	
		b.privateParentMethod();
		d=(Derived)b;//widening
		d.childSpecial();
		System.out.println(d.getClass());
	}
}

class Derived extends ConstructorBasics {

	public Derived() {
		System.out.println("child default constructor");
		ConstructorBasics.staticParentMethod();
		ConstructorBasics b = new ConstructorBasics();
		//System.out.print(b.a); out side of the class not possible
		//b.privateParentMethod();outside the class not possible
	}

	public Derived(int n, String name) {
		// this();In constructor we can't use this and super together
		super(n, name);

	}

	@Override // possible, we can increase the level of visibility but can't decrease
	public void test1() {
		System.out.println("Child protected method");
		// System.out.print(name);
	}
	
	public void childSpecial() {
		System.out.println("Child special method");
	}

	/*
	 * @Override 
	 * private void test() {
	 * 
	 * }//Cannot reduce the visibility of the inherited method from
	 * ConstructorBasics
	 */

	/*
	 * @Override 
	 * public static void staticParentMethod() {
	 * 
	 * }will give error can't override static methods
	 */

}
