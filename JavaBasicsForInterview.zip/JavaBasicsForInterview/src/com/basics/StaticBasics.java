package com.basics;

public class StaticBasics {

	private static int count; // static variables cna take default values if we don't assign values

	static {
		System.out.println(count);

		main(null);
	}

	public StaticBasics() {
		/*
		 * static {
		 * 
		 * } // not possible since static is calss level but constructor is object level
		 */
		// static int data; //not possible
		int data;

	}

	public static void main(String[] args) {  
		System.out.println("main method invoked");
		TestStatic ts = new TestStatic();
	}

	private void privateStatic() {
		System.out.println("Private static method");
	}
}

 class TestStatic {
	static {
		// StaticBasics.privateStatic();
		// System.out.println(StaticBasics.count); //not possible since count is private
		// and private can be accessible with in the class only
		System.out.println("TestStatic static block");
		StaticBasics.main(null);
	}

}