package com.basics;




public class InnerClassBasics {
	
	public static void main(String[] args) {
		//int = 0;
		Outer out = new Outer();
		Outer.Inner in = out.new Inner();
	//	out.showOuterData(); not posible since method belongs to inner only. 
		in.showOuterData();
	//	in.outerClassMethod(); // not possible since the method.
	    //Outer.PrivateInnerClas pvic = out.new PrivateInnerClass(); //not possible since class is private
	}

}

class Outer{
	
	int data = 0;
	/**
	 * 
	 * @author shaba
	 *nested inner class
	 */
	public void outerClassMethod() {
		System.out.println("Outer class method");
		PrivateInnerClas  pvc = new PrivateInnerClas(); //creation of Objects for inner private class
		pvc.accessCheck();
	}
	
	 class Inner{
	
		public void showOuterData() {
			System.out.println("Outer class data is "+data);
			System.out.println("Invoking outer form inner class method");
			outerClassMethod();
		}
		
	}
	 
	 private class PrivateInnerClas {
		 
		 public void accessCheck() {
			 System.out.println("private Inner class method ");
		 }
	 }
}
