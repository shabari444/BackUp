package com.basics;

import java.util.Map;
import java.util.Collections;
import java.util.TreeMap;

/**
 * Tree Map stores  in sorting order of keys.
 * @author shaba
 *
 */
public class TreeMapBasics {

	public static void main(String[] args) {
		Map<String, Double> treemap = new TreeMap<String, Double>();
		treemap.put("Sahabrish",15.000);
        treemap.put("Himanesh", 153.264);
        treemap.put("Sree", 159.00);
        System.out.println(treemap);
        //treeMap.reverseOrder();
        
		
	}
}
