package com.basics;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
//import java.io.IOException;

public class ArrayListBasics {

	public static void main(String[] args) throws ParseException,Exception {
		System.out.println("String array method");
		List<String> list = new ArrayList<String>();
		//list.add(1,"Sai");
		// list.add(10,"Shabrish"); throws exception
		// list.add(21,"Sree"); throws exception since this method is only for inserting
		// the element with in the size of the list not for adding at beyond size position
		System.out.println(list);
		SimpleDateFormat sdf = new SimpleDateFormat("dd mm yyyy");
		Date d = sdf.parse("19 08 1995");
		System.out.println(d);
		Date d1 = new Date(1995,8,19);
		System.out.println(d1);
		Scanner sc = new Scanner(System.in);	
		StringBuffer sb = new StringBuffer();
		sb.append("hi").append(" bye ");
		System.out.println(sb.toString().length());
		//sb.deleteCharAt(sb.)
		System.out.println(sb.toString().trim().length());
	}

	public static void main(int args) {
		System.out.println("int  method");
	}

	public static void main() {
		System.out.println("empty method");
	}

	public static void main(String arg) {
		System.out.println("String method");
	}

}
