package com.basics;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

public class Human {

	private String name;
	private List<Asset> assets;

	public Human() {

	}

	public Human(String name, List<Asset> assets) {
		super();
		this.name = name;
		this.assets = assets;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Asset> getAssets() {
		return assets;
	}

	public void setAssets(List<Asset> assets) {
		this.assets = assets;
	}

	public Human load(InputStream input) throws Exception {

		Human human = null;

		return human;

	}

	public void save(OutputStream output) throws IOException, ParseException {
		PrintWriter pw = new PrintWriter(output);
		boolean isNameExist = name != null ? true : false;
		if (isNameExist) {
			System.out.println(name);
			pw.write(name);
			pw.write("\n");
		}
		boolean isAssetExist = assets != null ? true : false;
        if(isAssetExist) {
        	for(Asset as : assets) {
        		System.out.println(as);
        		pw.write(as.toString()); 
        		//pw.write("\n");
        	}
        }
		
	}

	public static void main(String args[]) throws IOException, ParseException {

		List<Asset> assets1 = Arrays.asList(new Asset("land1", 40000), new Asset("land2", 508490));
		List<Asset> assets2 = null;

		InputStream fs1 = new FileInputStream("C:\\Users\\shaba\\OneDrive\\Documents\\Human1.txt");
		OutputStream fo1 = new FileOutputStream("C:\\Users\\shaba\\OneDrive\\Documents\\Human1.txt");
		OutputStream fo2 = new FileOutputStream("C:\\Users\\shaba\\OneDrive\\Documents\\Human2.txt");
		InputStream fs2 = new FileInputStream("C:\\Users\\shaba\\OneDrive\\Documents\\Human2.txt");

		Human one = new Human("One", assets1);
		one.save(fo1);
       
		Human two = new Human("Two", assets2);
		two.save(fo2);

	}

}
