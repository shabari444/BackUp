package com.basics;

public class StaticClassBasics {

	OuterForStatic.StaticInner in = new OuterForStatic.StaticInner();
	OuterForStatic outst = new OuterForStatic();

}

/*
 * Not possible, static classes can't be created outside the classes. static
 * static class Example{
 * 
 * }
 */

class OuterForStatic {

	static class StaticInner {

		public void defaultStaticClass() {
			System.out.println("method of static inner class");
		}

	}

	public static void staticOuterMethod() {
		StaticInnerPrivate stp = new StaticInnerPrivate();
		// StaticInnerPrivate.stativInnerPublicMethod(); since method is not possible
		stp.stativInnerPublicMethod();

	}

	public void outerMethod() {

		StaticInnerPrivate stp = new StaticInnerPrivate();// possible since static can be accessed by both static and
															// non static
		stp.stativInnerPublicMethod();
		stp.staticInnerPrivate();
	}

	private static class StaticInnerPrivate {

		public void stativInnerPublicMethod() {
			System.out.println("Static Inner method");
			// defaultStaticClass(); not possible
		}
		
		private void staticInnerPrivate() {
			System.out.println("Static private inner");
		}
		
		

	}
}