package com.basics;

public class ConsumerProducerBasics {

	public static void main(String[] args) {
		int i = 9;

		Product pd = new Product();
		CountIncrementExe c1 = new CountIncrementExe(pd, "Thread_1");
		CountIncrementExe c2 = new CountIncrementExe(pd, "Thread_2");
		Thread t1 = new Thread(c1);
		Thread t2 = new Thread(c1);
		t1.start();
		t2.start();
		
		/*
		 * synchronized(Integer.valueOf(i)) {
		 * 
		 * for( i =9; i>0;i--) { System.out.println("main block "+i); } }
		 */
		 

	}

}

class CountIncrementExe implements Runnable {

	 Product pd;
	String name;

	public CountIncrementExe() {
	}

	public CountIncrementExe(Product pd, String name) {
		this.pd = pd;
		this.name = name;
	}

	@Override
	public void run() {
		System.out.println("Thread name = " + name + "...........started");
		pd.printCount();
		System.out.println("Thread name = " + name + "...........End");

	}

}

class Product {
	String name;
	int count;

	public  void printCount() {
		for (int i = 0; i < 5; i++) {
			System.out.println(count++);
		}
	}
}
