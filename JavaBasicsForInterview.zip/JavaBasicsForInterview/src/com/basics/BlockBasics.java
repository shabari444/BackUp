package com.basics;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class BlockBasics {
	
	public static void main(String[] args) {
		
		List<Block> exList = new ArrayList();
		List<Block> linkList = new LinkedList();
		
		Block b = new Block();
		Block b2 = new Block();
				}

}

class Block{
	
	private int noOflegs;
	
	{
		System.out.println("Instance block 1");
	}
	
	static{
		System.out.println("static block 1");
	}
	
	{
		System.out.println("Instance block 2");
	}
	
	static{
		System.out.println("static block 2");
	}
	
	public Block() {
		System.out.println("Constructror");
	}
	
	static{
		System.out.println("static block 3");
	}
	
	
}