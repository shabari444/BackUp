package com.basics;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class PersonFromFile {
	
	public static final List<Person> PEOPLE = new ArrayList<>();

    public static void main(String[] args) throws FileNotFoundException,IOException, ParseException{
        
        FileReader fr = new FileReader("C:\\Users\\shaba\\OneDrive\\Documents\\PeoplesList.txt");
        int i = 0;
        List<String> sf = new ArrayList<String>();
        StringBuffer sb = new StringBuffer();
        while((i = fr.read() )!= -1) {
        	//System.out.print((char)i);
        	if((char)i=='\n') {
        		sf.add(sb.toString());
        		sb = new StringBuffer();
        	}else {
        		sb.append((char)i);
        	}
        		
        	
        }
        System.out.println(sf);
        Scanner sc = new Scanner(fr);
        System.out.println("\n "+sc);
        System.out.println(sc.hasNext());
        System.out.println(sc.nextLine());
       // fr.close();
       
        while(sc.hasNext()){
        	System.out.println("Inside while loop");
            String [] baseArray = sc.nextLine().split(" ");
            System.out.println(baseArray);
           // boolean isDigit = false;
            StringBuffer sbName = new StringBuffer();
            StringBuffer sbDob = new StringBuffer();
            for(String s: baseArray){
                try{
                    Integer.parseInt(s);
                    sbDob.append(s).append(" ");
                } catch(Exception e){
                    sbName.append(s).append(" ");
                }
            }
            //sbName.delete(sbName.toString().charAt(sbName.toString().length()-1));
            //sbDob.delete(sbDob.toString().charAt(sbDob.toString().length()-1));
            SimpleDateFormat sdf = new SimpleDateFormat("dd MM yyyy");
            Date d = sdf.parse(sbDob.toString().trim());
            System.out.println(sbName);
            System.out.println(sbDob);
            PEOPLE.add(new Person(sbName.toString().trim(),d));
        }
        System.out.println(PEOPLE);

    }

}

class Person{
	private String name;
	private Date dob;
	
	public Person(String name, Date dob) {
		this.name = name;
		this.dob = dob;
	}
}
