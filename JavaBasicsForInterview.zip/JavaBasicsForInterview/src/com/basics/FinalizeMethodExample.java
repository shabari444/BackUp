package com.basics;

/*
 * System.gc runs on Deamon threa so we cant gaurantee the flow of execution for below program
 * 
 *  Main method may execute first or finalize method may execute first.
 *  Finalize method will executed just before destroying the object
 */

public class FinalizeMethodExample {
	
	public static void main (String[] args) {
		
		FinalizeMethodExample fme = new FinalizeMethodExample();
		
		fme = null;
		
		System.gc();
		
		System.out.println("Main Method execution 1");
		
		System.out.println("Main Method execution 2");
		
		fme = new FinalizeMethodExample();
		
		System.out.println(fme.getClass());
		
	}

	@Override
	protected void finalize() {
		System.out.println("executing finalize method1");
		System.out.println("executing finalize method2");
		System.out.println("executing finalize method3");
	}
}
