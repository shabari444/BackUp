package com.basics;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class SortingEmployee {

	public static void main(String[] args) throws IOException, ParseException,FileNotFoundException {

		FileReader bf = new FileReader(new File("C:\\Users\\shaba\\OneDrive\\Desktop\\EmployeeFile.txt"));
		// int readLine = 0;
		List<Employee> employeeList = new LinkedList<Employee>();

		// System.out.print(bf.read());

		int i = -1;
		List<String> empString = new ArrayList<String>();
		StringBuffer sb = new StringBuffer();
		while ((i = bf.read()) != -1) {
			if ((char) i == '\n') {
				empString.add(sb.toString());
				sb = new StringBuffer();
			} else {
				sb.append((char) i);
			}

		}

		System.out.print(empString);

		for (String readLine : empString) {
		
			boolean isExist = false;
			String[] employeeInfo = readLine.split(" ");

			String empName = employeeInfo[0];
			double salary = Double.parseDouble(employeeInfo[1]);
			for (Employee em : employeeList) {
				if (em.getName().equals(empName)) {
					em.setSalary(em.getSalary() + Double.parseDouble(employeeInfo[1]));
					System.out.println("Duplicate found "+em);
					isExist = true;
				}
			}
			if (!isExist) {
				employeeList.add(new Employee(empName, salary));
			}
		}

		for (Employee e : employeeList) {
			System.out.println(e.toString());
		}
		System.out.println("\nAfter Sorting \n");
		Collections.sort(employeeList);
		for (Employee e : employeeList) {
			//System.out.println(e.toString());
			System.out.println(e.getName());
			break;
		}

	}
}

class Employee implements Comparable<Employee> {
	private String name;
	private double salary;

	public Employee() {

	}

	public Employee(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	/*
	 * @Override public int compareTo(Employee e) { return
	 * this.getName().compareTo(e.getName()); }
	 */
	 @Override
	    public int compareTo(Employee e){
	        if(this.getSalary() == e.getSalary())
	        return 0;
	        else
	        return this.getSalary()>e.getSalary() ? -1 : 1;
	    }
	@Override
	public String toString() {

		return name + " " + salary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
}
