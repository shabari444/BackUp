module JavaBasicsForInterview {
}