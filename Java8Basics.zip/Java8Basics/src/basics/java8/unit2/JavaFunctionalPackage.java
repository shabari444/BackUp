/*
 * To demonstrate the usage of package java.util.function
 */

package basics.java8.unit2;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import basics.java8.unit1.LamdaExpression;

public class JavaFunctionalPackage {

	public static void main(String[] args) {
		List<LamdaExpression> exList = Arrays.asList(new LamdaExpression(21, 59.6), new LamdaExpression(23.6, 54.9),
				new LamdaExpression(98.45, 264.8));
		System.out.println("list of object whose A value is >10 are");
		perform(exList, (l) -> l.getA() > 10, (l) -> System.out.println(l));
		System.out.println("list of object whose B value > A value are");
		perform(exList, (l) -> l.getB() > l.getA(), (l) -> System.out.println("B's value of object is " + l.getB()));
		
		/*
		 * perform(exList,()->, (l)->System.out.println("blank"));
		 */
		 

	}

	private static void perform(List<LamdaExpression> exList, Predicate<LamdaExpression> predicate,
			Consumer<LamdaExpression> consumer) {
		for (LamdaExpression l : exList) {
			//System.out.println(consumer.andThen((Consumer<? super LamdaExpression>) l));
			System.out.println(predicate.negate());
			if (predicate.test(l)) {
				consumer.accept(l);
			}
		}
	}
}
