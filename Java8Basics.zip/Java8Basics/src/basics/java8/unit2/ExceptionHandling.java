package basics.java8.unit2;

import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;

public class ExceptionHandling {

	public static void main(String[] args) {

		List<Integer> vList = Arrays.asList(1, 2, 5, 9, 3);
		int key = 2;
		performOperation(vList, key, wrappedBiConsumer((v, k) -> System.out.println(v %(v-k))));
		System.out.println("execution of performOperation is completed");

	}

	public static void performOperation(List<Integer> vList, Integer k, BiConsumer<Integer, Integer> consumer) {
		for (int i = 0; i <vList.size(); i++)
			consumer.accept(vList.get(i), k);
	}

	public static BiConsumer<Integer, Integer> wrappedBiConsumer(BiConsumer<Integer, Integer> bi) {

		return (v, k) -> {
			try {
				System.out.println("Execution through wrappedBiConsumer");
				bi.accept(v, k);
			} catch (ArrayIndexOutOfBoundsException ex) {
				System.out.println("Exception caught, info is " + ex.getMessage());
			} catch (ArithmeticException are) {
				System.out.println("Exception caught, info is " + are.getMessage());
			}
		};

	}

}
