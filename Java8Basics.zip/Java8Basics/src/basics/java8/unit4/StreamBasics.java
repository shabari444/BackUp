package basics.java8.unit4;

import java.util.Arrays;
import java.util.Comparator;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.IntStream;

import basics.java8.unit1.Student;

public class StreamBasics {

	public static void main(String[] args) {

		List<Student> studentList = Arrays.asList(new Student("Sai", 11, "5th"), new Student("Sony", 16, "11th"),
				new Student("Shabarish", 12, "7th"), new Student("Rahul", 15, "10th"),
				new Student("Himanesh", 14, "9th"), new Student("Harshith", 7, "2th"));

		// System.out.println("Students details whose age > 13");
		studentList.stream().// filter((s)->s.getAge()>13).
				map(s -> {
					s.setName(s.getName().toUpperCase());
					// System.out.println(s);
					return s;

				}).sorted().forEach(System.out::println);
		
		System.out.println("Sorting as per the names");

		studentList.stream().sorted((s1, s2) -> s1.getName().compareTo(s2.getName())).forEach(System.out::println);

		System.out.println("Sorting as per the standard and age > 10");
		studentList.stream().sorted((s1,s2)->{return s2.getStandard().
				substring(0, s2.getStandard().indexOf("th")).
				compareTo(s1.getStandard().
						substring(0, s1.getStandard().indexOf("th")));
		})
		.filter((s)->s.getAge()>10).forEach(System.out::println);

		List<Integer> intList = Arrays.asList(1, 2, 35, 6, 29, 17, 63, 28);
		intList.stream().sorted().forEach(System.out::println);
		IntSummaryStatistics intSummary = intList.stream().limit(2).mapToInt(x -> x).summaryStatistics();
		System.out.println(intSummary);
	}

}
