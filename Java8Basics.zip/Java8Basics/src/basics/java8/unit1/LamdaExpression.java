package basics.java8.unit1;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LamdaExpression {

	private double a;
	private double b;

	/**
	 * @param a
	 * @param b
	 */
	public LamdaExpression(double a, double b) {
		super();
		this.a = a;
		this.b = b;
	}

	@Override
	public String toString() {
		return "LamdaExpression [a=" + a + ", b=" + b + "]";
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	public void performBinaryOperation(MathOperation op) {
		op.operation(a, b);
	}

	interface MathOperation {
		public void operation(double a, double b);
	}

	interface Condition {
		public boolean isexCondition(LamdaExpression l);
	}

	public static void conditionCheck(List<LamdaExpression> exl, Condition c) {
		for (LamdaExpression l : exl) {
			if (c.isexCondition(l)) {
				System.out.println(l.toString());
			}
		}
	}

	public static void main(String[] args) {
		// System.out.println("Welcome to Lamda Expression demo");
		LamdaExpression ex = new LamdaExpression(51, 59);
		System.out.print("Divison of given numbers is ");
		ex.performBinaryOperation((c, d) -> System.out.println(c / d));
		System.out.print("Mod of given numbers is ");
		ex.performBinaryOperation((c, d) -> System.out.println(c % d));

		List<LamdaExpression> exList = Arrays.asList(new LamdaExpression(51, 89), new LamdaExpression(21, 69),
				new LamdaExpression(06, 65));

		System.out.println("List before sorting " + exList);
		/*
		 * for(LamdaExpression exp : exList) System.out.println(exp.toString());
		 */

		Collections.sort(exList, (l1, l2) -> (int) (l1.getA() - l2.getA()));

		System.out.println("List after sorting on basis of A is " + exList);
		/*
		 * for(LamdaExpression exp : exList) System.out.println(exp.toString());
		 * 
		 */
		System.out.println("Objects which has A value greater than 20 are shown below");
		/*
		 * for (LamdaExpression l : exList) { if (ex.conditioncheck((a) -> l.getA() >
		 * 20.0)) { System.out.println(l.toString()); } }
		 */
		conditionCheck(exList, (l) -> l.getA() > 20);
		

		System.out.println("Objects which has A value less <= 20 are shown below");
		conditionCheck(exList, (l) -> l.getA() <= 20);
		/*
		 * for (LamdaExpression l : exList) { if (ex.conditioncheck((a) -> l.getA() <=
		 * 20)) { System.out.println(l.toString()); } }
		 */

	}
}
