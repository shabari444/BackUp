/*
 * In case of Lamda This reference to the object on which the invocation happened 
 * In case of inner class reference to the Object on which the implementation happened.
 * Lets see the below example for better understanding
 */

package basics.java8.unit3;

public class DiffLamdaAndInnerClass {

	int a = 89;
	int b = 56;

	@Override
	public String toString() {
		return "DiffLamdaAndInnerClass [a=" + a + ", b=" + b + "]";
	}

	public static void main(String[] args) {
		DiffLamdaAndInnerClass diff = new DiffLamdaAndInnerClass();

		// implementation using inner class

		diff.performTest(new Example() {
			public void test() {
				System.out.println(this.getClass());
				System.out.println(this);
			}

			public String toString() {
				return "Implementation through inner class";
			}
		});

		// implementation using lamda expression
		diff.performTest(() -> {
			// System.out.println(this.getClass());//This wont work since the execution in
			// static reference
			System.out.println("hi,direcet execution throuf=gh main method implementation through lamda expression");
		});
		diff.execute();
	}

	interface Example {
		public void test();
	}

	public void performTest(Example ex) {
		ex.test();
	}

	public void execute() {
		performTest(() -> {
			System.out.println("hi,perorming execution through lamda in execute method");
			System.out.println(this.getClass());
			System.out.println(this);
		});
	}
}
