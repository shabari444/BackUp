package basics.java8.unit3;

import java.util.function.Consumer;

public class ClosuresExample {

	public static void main(String[] args) {

		int a = 6;
		int b = 8;

		perform(a, (x) -> {
			// = b + 9;//This line wont work because we can have only read scope, but not
			// write scope, since its not a local variable of the accept method, so in this
			// case the b variable is treated final variable at this scope
			int sum = x + b;
			System.out.println("Sum of a and b is " + sum);
		});

	}

	public static void perform(int a, Consumer<Integer> con) {
		con.accept(a);
	}

}
