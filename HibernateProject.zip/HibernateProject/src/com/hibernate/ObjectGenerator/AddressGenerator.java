package com.hibernate.ObjectGenerator;

import java.util.ArrayList;
import java.util.List;

import com.hibernate.pojos.Address;

public class AddressGenerator extends ObjectGenerator {
	
	private List<ObjectGenerator> addressList = new ArrayList<ObjectGenerator>();
	
	

	@Override
	public List<ObjectGenerator> getObjects() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setObjects() {
		// TODO Auto-generated method stub
		
		//this.addressList.addAll(new Address("A01","Rajagiri","682030","Kakkanad"));
	}

}
