package com.hibernate.ObjectGenerator;

import java.util.List;

import com.hibernate.pojos.Student;
import com.hibernate.pojos.Address;

public abstract class ObjectGenerator {

	public Object getObjectType(String className) {

		if ("Student".equals("className")) {
			return new StudentGenerator();
		}
		if ("Address".equals("className")) {
			return new AddressGenerator();
		}
		return null;
	}

	public abstract List<ObjectGenerator> getObjects();
	
	public abstract void setObjects();

}
