package com.hibernate.ObjectGenerator;

import java.util.ArrayList;
import java.util.List;

public class StudentGenerator extends ObjectGenerator {
	
	private List<ObjectGenerator> studentsList = new ArrayList<ObjectGenerator>();
	
	
	
	 

	@Override
	public List<ObjectGenerator> getObjects() {
		// TODO Auto-generated method stub
		return studentsList;
	}

	@Override
	public void setObjects() {
		// TODO Auto-generated method stub
	}

}
