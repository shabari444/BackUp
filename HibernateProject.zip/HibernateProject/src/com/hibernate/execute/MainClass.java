package com.hibernate.execute;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.pojos.Address;

public class MainClass {
	
	public static void main(String[] args) {
		Address add = new Address("AD101", "Kakkanad", "Kochi", "682030");
		SessionFactory sfc = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = sfc.openSession();
		session.beginTransaction();
		session.save(add);
		session.getTransaction().commit();
		
	}

}
