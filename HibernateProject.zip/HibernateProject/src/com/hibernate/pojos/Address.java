package com.hibernate.pojos;

import javax.persistence.Entity;

@Entity
public class Address {

	private String addressId;
	private String street;
	private String pincode;
	private String city;

	public Address(String addressId, String street, String pincode, String city) {
		super();
		this.addressId = addressId;
		this.street = street;
		this.pincode = pincode;
		this.city = city;
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
