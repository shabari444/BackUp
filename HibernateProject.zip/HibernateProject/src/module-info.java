module HibernateProject {
	requires java.persistence;
	requires org.hibernate.orm.core;
}